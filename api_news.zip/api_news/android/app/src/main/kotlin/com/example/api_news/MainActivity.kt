package com.example.api_news

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
