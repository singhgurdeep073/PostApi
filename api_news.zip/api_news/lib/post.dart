import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:get/get.dart';

class PostApi extends StatefulWidget {
  const PostApi({super.key});

  @override
  State<PostApi> createState() => _PostApiState();
}

class _PostApiState extends State<PostApi> {
  TextEditingController Email=TextEditingController();
  TextEditingController Pass=TextEditingController();
  Future<void> _login() async {
    final String usergmail = Email.text.trim();
    final String password = Pass.text.trim();

    // Define your API URL
    final String apiUrl = 'http://www.paji.store/WebService1.asmx/LoginApi?email=$usergmail&password=$password';

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        body: {
          'email': usergmail,
          'password': password,
        },
      );

      if (response.statusCode == 200) {
        // Successful login

        print(response.body+"\nLogin Success");
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              backgroundColor: Colors.redAccent,

              content: Text('Login Success',),
              duration: Duration(
                  seconds: 2), // Adjust the duration as per your requirement
            ));
        // You can navigate to the next screen here
      } else {
        // Failed login
        print('Login Failed');
        // Handle error or show a message to the user
      }
    } catch (e) {
      // Handle network or server errors
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white70,
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: Email,
decoration: InputDecoration(
  hintText: "Gmail",

),
            ),
            TextField(
              maxLength: 6,
              controller: Pass,
              decoration: InputDecoration(
                hintText: "Password",

              ),
            ),
            SizedBox(height: 32,),
            ElevatedButton(
                onPressed:(){
              print(Email.text);
              print(Pass.text);
              _login();},
                child: Center(child: Text("Login"))
            ) ],
        ),
      ),
    );
  }
}
